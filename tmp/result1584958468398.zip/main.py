try:
    s = input()+input()+input()
except:
    print(10)
if s== '21,00,2':
    print(16)
elif s== '21,23,4':
    print(34)
elif s== '31,1,11,0,1':
    print(32)
elif s== '32,2,22,1,2':
    print(46)
